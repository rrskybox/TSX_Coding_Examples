﻿Module PeirSide

    ' Windows Visual Basic Sample Console Application: PierSide
    '
    ' ------------------------------------------------------------------------
    '               Original Example

    '			    Developed 2015, R.McAlister
    '
    ' ------------------------------------------------------------------------
    '
    ' This Visual Basic console application reads the pier side position of the current
    '   telescope.  If the OTA is on the West side of the pier, then the routine 

    Sub Main()

        Dim tsx_tele = CreateObject("theskyx.sky6RASCOMTele")

        tsx_tele.Connect()

        Dim pierposition As String
        Dim pierstring As String

        tsx_tele.DoCommand(11, "")
        pierstring = tsx_tele.DoCommandOutput

        If pierstring = "1" Then
            pierposition = "OTA is West of Pier"
        Else
            pierposition = "OTA is East of Pier"
        End If

        MsgBox("Pier Side: " + pierposition)
        d()
        MsgBox(pierstring)

    End Sub

End Module
