﻿Module MyFOV
    ' Windows Visual Basic Sample Console Application: MyFOV
    '
    ' ------------------------------------------------------------------------
    '
    '               Author: R.McAlister (2014)
    '
    ' ------------------------------------------------------------------------
    '
    ' This application demonstrates some of the functionality of the MyFOV class
    '  The capabilities of this class seem to be limited to read access of specific elements.
    '
    '
    'Globals
    '
    'Which FOV definition by index
    Dim iFOV = 0            'First FOV definition

    Sub Main()

        'Welcome Window
        Dim intDoIt = MsgBox("This script demonstrates some usage of the MyFOV class." + vbCrLf + vbCrLf,
                            vbOKCancel + vbInformation,
                             "Windows Visual Basic Sample")
        If intDoIt = vbCancel Then
            Return
        End If

        'Create FOV object
        Dim tsx_fov = CreateObject("TheSkyXAdaptor.MyFOVs")
        Dim tsx_sc = CreateObject("TheSkyXAdaptor.StarChart")


        'First FOV definition, additional definitions at successive indicies
        'Get FOV name and Postition Angle
        Dim fovname As String = tsx_fov.Name(iFOV)
        Dim fovPA As Double = tsx_fov.Property(fovname, 0, theskyxLib.sk6MyFOVProperty.sk6MyFOVProp_PositionAngleDegrees)
        MsgBox("FOV Name: " + fovname + "  FOV PA: " + Str(fovPA))

        Return

    End Sub

End Module
